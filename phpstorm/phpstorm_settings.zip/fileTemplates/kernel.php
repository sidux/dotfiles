<?php

declare(strict_types=1);

use Symfony\Component\VarDumper\VarDumper;

require '/Users/ahmed.lebbada/Projects/${PROJECT_NAME}/app/autoload.php';

function invoke(\$object, \$methodName, array ...\$parameters)
{
    \$reflection = new \ReflectionClass(\$object);
    \$method = \$reflection->getMethod(\$methodName);
    \$method->setAccessible(true);

    return \$method->invokeArgs(\$object, \$parameters);
}

\$kernel = new AppKernel('test', false);
\$kernel->boot();
\$container = \$kernel->getContainer();
\$container = \$container->has('test.service_container') ? \$container->get('test.service_container') : \$container;

VarDumper::dump('Oh hi there');

